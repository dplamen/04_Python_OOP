from project.library import Library
from unittest import TestCase, main


class TestLibrary(TestCase):
    def setUp(self) -> None:
        self.lib = Library("Test1")

    def test_init(self):
        self.assertEqual("Test1", self.lib.name)
        self.assertEqual({}, self.lib.books_by_authors)
        self.assertLogs({}, self.lib.readers)

    def test_if_name_empty_string(self):
        with self.assertRaises(Exception) as ex:
            self.lib1 = Library("")
        self.assertEqual("Name cannot be empty string!", str(ex.exception))

    def test_add_book(self):
        self.lib.add_book("Author", "Robin")
        self.assertEqual({"Author": ["Robin"]}, self.lib.books_by_authors)

    def test_add_reader(self):
        self.lib.add_reader("John")
        self.assertEqual({"John": []}, self.lib.readers)

    def test_add_reader_already_in_library(self):
        self.lib.add_reader("John")
        result = self.lib.add_reader("John")
        self.assertEqual("John is already registered in the Test1 library.", result)

    def test_rent_book_if_reader_not_member(self):
        self.lib.add_book("Author", "Robin")
        result = self.lib.rent_book("Peter", "Author", "Robin")
        self.assertEqual("Peter is not registered in the Test1 Library.", result)

    def test_rent_book_if_author_not_presented(self):
        self.lib.add_reader("John")
        self.lib.add_book("Author", "Robin")
        result = self.lib.rent_book("John", "test", "Robin")
        self.assertEqual("Test1 Library does not have any test's books.", result)

    def test_rent_book_if_title_not_presented(self):
        self.lib.add_reader("John")
        self.lib.add_book("Author", "Robin")
        result = self.lib.rent_book("John", "Author", "test")
        self.assertEqual("""Test1 Library does not have Author's "test".""", result)

    def test_rent_book_successfully(self):
        self.lib.add_reader("John")
        self.lib.add_book("Author", "Robin")
        self.lib.rent_book("John", "Author", "Robin")
        self.assertEqual([{"Author": "Robin"}], self.lib.readers["John"])
        self.assertEqual({"Author": []}, self.lib.books_by_authors)


if __name__ == '__main__':
    main()






