from project.space_station import SpaceStation

space = SpaceStation()
space.add_astronaut("Biologist", "Peter")
space.add_astronaut("Geodesist", "John")
space.add_planet("Earth", "Item1, Item2, Item3, Item1, Item2, Item3, Item1, Item2, Item3, Item1, Item2, Item3, Item1, Item2, Item3, Item1, Item2, Item3, Item1, Item2, Item3")
space.add_planet("Mars", "Item1, Item2, Item3")
space.recharge_oxygen()
space.recharge_oxygen()
print(space.send_on_mission("Earth"))
print(space.send_on_mission("Mars"))
print(space.report())
